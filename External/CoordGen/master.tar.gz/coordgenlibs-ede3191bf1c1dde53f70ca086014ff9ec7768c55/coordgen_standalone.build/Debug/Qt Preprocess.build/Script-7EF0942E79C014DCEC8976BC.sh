#!/bin/sh
make -C /Users/nicola/schrodinger/coordgen_standalone/ -f coordgen_standalone.xcodeproj/qt_preprocess.mak
