Rebuild Support Libraries
=========================

In order to rebuild the servlet, you need the file servlet-api in this directory.
It's available in the lib directory of the Apache Tomcat installation, which can be
found at http://tomcat.apache.org/index.html

The build has been tested with version 7.0 of the Tomcat distribution, but should also
run with any version higher than 6.0.
